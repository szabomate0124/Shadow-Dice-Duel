package com.example.dicegame;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView whiteDice, blackDice;
    TextView scoreText, shadowLevelText;
    Button rollButton;

    Random random = new Random();
    int score = 0;
    int shadowLevel = 0;

    int[] whiteDiceImages = {
            R.drawable.white1, R.drawable.white2, R.drawable.white3,
            R.drawable.white4, R.drawable.white5, R.drawable.white6
    };
    int[] blackDiceImages = {
            R.drawable.black1, R.drawable.black2, R.drawable.black3,
            R.drawable.black4, R.drawable.black5, R.drawable.black6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Edge-to-edge padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        whiteDice = findViewById(R.id.whiteDice);
        blackDice = findViewById(R.id.blackDice);
        scoreText = findViewById(R.id.scoreText);
        shadowLevelText = findViewById(R.id.shadowLevelText);
        rollButton = findViewById(R.id.rollButton);

        rollButton.setOnClickListener(v -> rollDice());

        updateUI();
    }

    private void rollDice() {

        // Animációk
        whiteDice.animate().rotationBy(360).setDuration(300).start();
        blackDice.animate().rotationBy(360).setDuration(300).start();

        whiteDice.animate().alpha(0f).setDuration(150).withEndAction(() -> whiteDice.setAlpha(1f));
        blackDice.animate().alpha(0f).setDuration(150).withEndAction(() -> blackDice.setAlpha(1f));

        int white = random.nextInt(6) + 1;
        int black = random.nextInt(6) + 1;

        // Képek frissítése
        whiteDice.setImageResource(whiteDiceImages[white - 1]);
        blackDice.setImageResource(blackDiceImages[black - 1]);

        Toast messageToast;


        if ((white == 1 && black == 6) || (white == 6 && black == 1)) {
            if (black > white) {
                shadowLevel += 4;
                messageToast = Toast.makeText(this, "Carpe Diem! Fekete győz, Árnyékszint +4", Toast.LENGTH_LONG);
            } else {
                score += 4;
                messageToast = Toast.makeText(this, "Carpe Diem! +4 pont", Toast.LENGTH_LONG);
            }
        }

        else if (white == black) {
            score += 2;
            messageToast = Toast.makeText(this, "Dupla Dobás! +2 pont", Toast.LENGTH_SHORT);
        }

        else if (white > black) {
            score += 1;
            messageToast = Toast.makeText(this, "Reménysugár! +1 pont", Toast.LENGTH_SHORT);
        }

        else {
            shadowLevel += 1;
            messageToast = Toast.makeText(this, "Sötét Ómen! Árnyékszint +1", Toast.LENGTH_SHORT);
        }

        messageToast.show();
        updateUI();

        if (shadowLevel >= 6) {
            gameOver();
        }
    }

    private void updateUI() {
        scoreText.setText("Pontszám: " + score);
        shadowLevelText.setText("Árnyékszint: " + shadowLevel);
    }

    private void gameOver() {
        Toast.makeText(this, "A Sötétség elnyelt! Játék vége.", Toast.LENGTH_LONG).show();
        rollButton.setEnabled(false);
    }
}
