package com.example.dicegame;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView whiteDice, blackDice;
    TextView scoreText, shadowLevelText;
    Button rollButton;

    Random random = new Random();
    int score = 0;
    int shadowLevel = 0;

    int[] whiteDiceImages = {
            R.drawable.side_1_pip, R.drawable.side_2_pips, R.drawable.side_3_pips,
            R.drawable.side_4_pips, R.drawable.side_5_pips, R.drawable.side_1_pip
    };

    int[] blackDiceImages = {
            R.drawable.side_1_pipblack, R.drawable.side_2_pipsblack, R.drawable.side_3_pipsblack,
            R.drawable.side_4_pipsblack, R.drawable.side_5_pipsblack, R.drawable.side_6_pipsblack
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        whiteDice = findViewById(R.id.whiteDice);
        blackDice = findViewById(R.id.blackDice);
        scoreText = findViewById(R.id.scoreText);
        shadowLevelText = findViewById(R.id.shadowLevelText);
        rollButton = findViewById(R.id.rollButton);

        rollButton.setOnClickListener(v -> rollDice());

        updateUI();
    }

    private void rollDice() {

        whiteDice.animate().rotationBy(360).setDuration(300).start();
        blackDice.animate().rotationBy(360).setDuration(300).start();

        int white = random.nextInt(6);
        int black = random.nextInt(6);

        whiteDice.setImageResource(whiteDiceImages[white]);
        blackDice.setImageResource(blackDiceImages[black]);

        Toast messageToast;

        if ((white == 0 && black == 5) || (white == 5 && black == 0)) {
            if (black > white) {
                shadowLevel += 4;
                messageToast = Toast.makeText(this,
                        "Carpe Diem! Fekete győz, Árnyékszint +4",
                        Toast.LENGTH_LONG);
            } else {
                score += 4;
                messageToast = Toast.makeText(this,
                        "Carpe Diem! +4 pont",
                        Toast.LENGTH_LONG);
            }
        } else if (white == black) {
            score += 2;
            messageToast = Toast.makeText(this,
                    "Dupla Dobás! +2 pont",
                    Toast.LENGTH_SHORT);
        } else if (white > black) {
            score += 1;
            messageToast = Toast.makeText(this,
                    "Reménysugár! +1 pont",
                    Toast.LENGTH_SHORT);
        } else {
            shadowLevel += 1;
            messageToast = Toast.makeText(this,
                    "Sötét Ómen! Árnyékszint +1",
                    Toast.LENGTH_SHORT);
        }

        messageToast.show();
        updateUI();

        if (shadowLevel >= 6) {
            gameOver();
        }
    }

    private void updateUI() {
        scoreText.setText("Pontszám: " + score);
        shadowLevelText.setText("Árnyékszint: " + shadowLevel);
    }

    private void gameOver() {
        Toast.makeText(this,
                "A Sötétség elnyelt! Játék vége.",
                Toast.LENGTH_LONG).show();
        rollButton.setEnabled(false);
    }
}
